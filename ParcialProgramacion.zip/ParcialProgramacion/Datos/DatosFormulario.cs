﻿using Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace Datos
{
    public class DatosFormulario
    {

        public string GuardarFormulario(Formulario form)
        {
            try
            {
                var wr = new StreamWriter("formularios.txt", true);
                wr.WriteLine(form.ToString());
                wr.Close();
                return "Datos guardados exitosamente";
            }catch(FileNotFoundException)
            {
                return "Error, archivo no encontrado";
            }
        }

        public List<Formulario> ListarFormularios()
        {
            List<Formulario> list = new List<Formulario>();
            
            try
            {
                var rd = new StreamReader("formularios.txt");
                var data = rd.ReadLine();
                while (data != null)
                {
                    var form = new Formulario
                    {
                        NumForm = int.Parse(data.Split(';')[1]),
                        PersonaAsociada = new Persona(data.Split(';')[2], data.Split(';')[3], bool.Parse(data.Split(';')[4])),
                        FechaDeclaracion = DateTime.ParseExact(data.Split(';')[5], "d/M/yyyy", null),
                        DiasExtemporaneo = int.Parse(data.Split(';')[6]),
                        ValorDeclarado = double.Parse(data.Split(';')[7]),
                        Sancion = double.Parse(data.Split(';')[8]),
                        TotalPagado = double.Parse(data.Split(';')[9])

                    };
                    list.Add(form);
                    data = rd.ReadLine();
                }
                rd.Close();
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Error al cargar el archivo, no existe o fue eliminado. Se cargará el programa normalmente");
            }
            return list;
        }
    }
}
