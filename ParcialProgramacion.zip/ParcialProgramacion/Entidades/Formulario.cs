﻿using System;

namespace Entidades
{
    public class Formulario
    {
        public int NumForm { get; set; }
        public Persona PersonaAsociada{ get; set; }
        public double ValorDeclarado { get; set; }
        public DateTime FechaDeclaracion{ get; set; }
        public int DiasExtemporaneo{ get; set; }
        public double TotalPagado{ get; set; }
        public double Sancion { get; set; }

        public Formulario() { }
        public Formulario(int numForm, Persona personaAsociada, double valorDeclarado, DateTime diaDeclaracion, int diasExtemporaneo, double totalPagado, double sancion)
        {
            NumForm = numForm;
            PersonaAsociada = personaAsociada;
            ValorDeclarado = valorDeclarado;
            FechaDeclaracion = diaDeclaracion;
            DiasExtemporaneo = diasExtemporaneo;
            TotalPagado = totalPagado;
            Sancion = sancion;
        }


        public override String ToString()
        {
            return $"F;{NumForm};{PersonaAsociada.Id};{PersonaAsociada.Name};" +
                $"{PersonaAsociada.Emplazado};{FechaDeclaracion.Day}/{FechaDeclaracion.Month}/{FechaDeclaracion.Year};" +
                $"{DiasExtemporaneo};{ValorDeclarado};{Sancion};{TotalPagado}";
        }
    }
}
