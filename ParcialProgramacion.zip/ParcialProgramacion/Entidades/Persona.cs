﻿namespace Entidades
{
    public class Persona
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public bool Emplazado{ get; set; }

        public Persona() { }
        public Persona(string id, string name, bool emplazado)
        {
            Id = id;
            Name = name;
            Emplazado = emplazado;
        }
    }
}
