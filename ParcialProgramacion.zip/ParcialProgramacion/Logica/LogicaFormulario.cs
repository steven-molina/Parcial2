﻿using Datos;
using Entidades;
using System.Collections.Generic;

namespace Logica
{
    public class LogicaFormulario
    {
        private List<Formulario> formularios;
        private readonly DatosFormulario datosFormulario = new DatosFormulario();

        public LogicaFormulario()
        {
            CargarFormularios();
        }


        private Formulario Buscar(Formulario form)
        {
            foreach(var f in formularios)
            {
                if(f.NumForm == form.NumForm)
                {
                    return f;
                }
            }
            return null;
        }
        public string AgregarFormulario(Formulario form)
        {

            if(Buscar(form) == null)
            {
                if (form.PersonaAsociada.Emplazado)
                {
                    form.Sancion = form.ValorDeclarado * form.DiasExtemporaneo * 0.03;
                }
                else
                {
                    form.Sancion = form.ValorDeclarado * form.DiasExtemporaneo * (4 * 1160000);
                }
                form.TotalPagado = form.ValorDeclarado + form.Sancion;

                formularios.Add(form);
                return datosFormulario.GuardarFormulario(form);
            }
            return "No se pudo guardar el formulario, ya el número de formulario está registrado";
        }
        private void CargarFormularios()
        {
            formularios = datosFormulario.ListarFormularios();
        }

        public List<Formulario> ListarFormularios()
        {
            return formularios;
        }
    }
}
