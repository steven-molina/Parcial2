﻿namespace Presentacion
{
    partial class MainWindow
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtValorDeclarado = new System.Windows.Forms.TextBox();
            this.declarado = new System.Windows.Forms.Label();
            this.fecha = new System.Windows.Forms.Label();
            this.txtFecha = new System.Windows.Forms.DateTimePicker();
            this.txtName = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.TextBox();
            this.id = new System.Windows.Forms.Label();
            this.txtNumForm = new System.Windows.Forms.TextBox();
            this.numFormulario = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.listEmplazamiento = new System.Windows.Forms.RadioButton();
            this.listNoEmplazamiento = new System.Windows.Forms.RadioButton();
            this.guardarForm = new System.Windows.Forms.Button();
            this.datosFormulario = new System.Windows.Forms.DataGridView();
            this.numForm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estadoEmplazado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valorDeclarado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sancion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.extemporaneo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalPagado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.normal = new System.Windows.Forms.RadioButton();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datosFormulario)).BeginInit();
            this.SuspendLayout();
            // 
            // txtValorDeclarado
            // 
            this.txtValorDeclarado.Location = new System.Drawing.Point(337, 122);
            this.txtValorDeclarado.Name = "txtValorDeclarado";
            this.txtValorDeclarado.Size = new System.Drawing.Size(127, 20);
            this.txtValorDeclarado.TabIndex = 19;
            // 
            // declarado
            // 
            this.declarado.AutoSize = true;
            this.declarado.Location = new System.Drawing.Point(234, 125);
            this.declarado.Name = "declarado";
            this.declarado.Size = new System.Drawing.Size(81, 13);
            this.declarado.TabIndex = 18;
            this.declarado.Text = "Valor declarado";
            // 
            // fecha
            // 
            this.fecha.AutoSize = true;
            this.fecha.Location = new System.Drawing.Point(517, 86);
            this.fecha.Name = "fecha";
            this.fecha.Size = new System.Drawing.Size(110, 13);
            this.fecha.TabIndex = 17;
            this.fecha.Text = "Fecha de declaración";
            // 
            // txtFecha
            // 
            this.txtFecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtFecha.Location = new System.Drawing.Point(633, 83);
            this.txtFecha.Name = "txtFecha";
            this.txtFecha.Size = new System.Drawing.Size(160, 20);
            this.txtFecha.TabIndex = 16;
            this.txtFecha.ValueChanged += new System.EventHandler(this.TxtFecha_ValueChanged);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(337, 83);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(127, 20);
            this.txtName.TabIndex = 15;
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Location = new System.Drawing.Point(219, 86);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(112, 13);
            this.name.TabIndex = 14;
            this.name.Text = "Nombre o razón social";
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(657, 43);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(136, 20);
            this.txtId.TabIndex = 13;
            // 
            // id
            // 
            this.id.AutoSize = true;
            this.id.Location = new System.Drawing.Point(515, 46);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(136, 13);
            this.id.TabIndex = 12;
            this.id.Text = "Identificación (Nit o cedula)";
            // 
            // txtNumForm
            // 
            this.txtNumForm.Location = new System.Drawing.Point(337, 43);
            this.txtNumForm.Name = "txtNumForm";
            this.txtNumForm.Size = new System.Drawing.Size(127, 20);
            this.txtNumForm.TabIndex = 11;
            // 
            // numFormulario
            // 
            this.numFormulario.AutoSize = true;
            this.numFormulario.Location = new System.Drawing.Point(224, 46);
            this.numFormulario.Name = "numFormulario";
            this.numFormulario.Size = new System.Drawing.Size(107, 13);
            this.numFormulario.TabIndex = 10;
            this.numFormulario.Text = "Numero de formulario";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.listEmplazamiento);
            this.flowLayoutPanel1.Controls.Add(this.listNoEmplazamiento);
            this.flowLayoutPanel1.Controls.Add(this.normal);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(43, 182);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(947, 42);
            this.flowLayoutPanel1.TabIndex = 21;
            // 
            // listEmplazamiento
            // 
            this.listEmplazamiento.AutoSize = true;
            this.listEmplazamiento.Location = new System.Drawing.Point(3, 3);
            this.listEmplazamiento.Name = "listEmplazamiento";
            this.listEmplazamiento.Size = new System.Drawing.Size(117, 17);
            this.listEmplazamiento.TabIndex = 0;
            this.listEmplazamiento.TabStop = true;
            this.listEmplazamiento.Text = "Con emplazamiento";
            this.listEmplazamiento.UseVisualStyleBackColor = true;
            this.listEmplazamiento.CheckedChanged += new System.EventHandler(this.ListEmplazamiento_CheckedChanged);
            // 
            // listNoEmplazamiento
            // 
            this.listNoEmplazamiento.AutoSize = true;
            this.listNoEmplazamiento.Location = new System.Drawing.Point(126, 3);
            this.listNoEmplazamiento.Name = "listNoEmplazamiento";
            this.listNoEmplazamiento.Size = new System.Drawing.Size(113, 17);
            this.listNoEmplazamiento.TabIndex = 1;
            this.listNoEmplazamiento.TabStop = true;
            this.listNoEmplazamiento.Text = "Sin emplazamiento";
            this.listNoEmplazamiento.UseVisualStyleBackColor = true;
            this.listNoEmplazamiento.CheckedChanged += new System.EventHandler(this.ListNoEmplazamiento_CheckedChanged);
            // 
            // guardarForm
            // 
            this.guardarForm.Location = new System.Drawing.Point(520, 125);
            this.guardarForm.Name = "guardarForm";
            this.guardarForm.Size = new System.Drawing.Size(273, 23);
            this.guardarForm.TabIndex = 22;
            this.guardarForm.Text = "Guardar Formulario";
            this.guardarForm.UseVisualStyleBackColor = true;
            this.guardarForm.Click += new System.EventHandler(this.GuardarForm_Click);
            // 
            // datosFormulario
            // 
            this.datosFormulario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datosFormulario.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numForm,
            this.NC,
            this.nombre,
            this.date,
            this.estadoEmplazado,
            this.valorDeclarado,
            this.sancion,
            this.extemporaneo,
            this.totalPagado});
            this.datosFormulario.Location = new System.Drawing.Point(46, 230);
            this.datosFormulario.Name = "datosFormulario";
            this.datosFormulario.Size = new System.Drawing.Size(944, 254);
            this.datosFormulario.TabIndex = 23;
            // 
            // numForm
            // 
            this.numForm.HeaderText = "# Formulario";
            this.numForm.Name = "numForm";
            this.numForm.ReadOnly = true;
            // 
            // NC
            // 
            this.NC.HeaderText = "Nit/Cédula";
            this.NC.Name = "NC";
            this.NC.ReadOnly = true;
            // 
            // nombre
            // 
            this.nombre.HeaderText = "Nombre/Razón Social";
            this.nombre.Name = "nombre";
            this.nombre.ReadOnly = true;
            // 
            // date
            // 
            this.date.HeaderText = "Fecha de declaración";
            this.date.Name = "date";
            this.date.ReadOnly = true;
            // 
            // estadoEmplazado
            // 
            this.estadoEmplazado.HeaderText = "Emplazado";
            this.estadoEmplazado.Name = "estadoEmplazado";
            this.estadoEmplazado.ReadOnly = true;
            // 
            // valorDeclarado
            // 
            this.valorDeclarado.HeaderText = "Valor declarado";
            this.valorDeclarado.Name = "valorDeclarado";
            this.valorDeclarado.ReadOnly = true;
            // 
            // sancion
            // 
            this.sancion.HeaderText = "Sanción";
            this.sancion.Name = "sancion";
            this.sancion.ReadOnly = true;
            // 
            // extemporaneo
            // 
            this.extemporaneo.HeaderText = "Dias Extemporaneo";
            this.extemporaneo.Name = "extemporaneo";
            // 
            // totalPagado
            // 
            this.totalPagado.HeaderText = "Total pagado";
            this.totalPagado.Name = "totalPagado";
            this.totalPagado.ReadOnly = true;
            // 
            // normal
            // 
            this.normal.AutoSize = true;
            this.normal.Checked = true;
            this.normal.Location = new System.Drawing.Point(245, 3);
            this.normal.Name = "normal";
            this.normal.Size = new System.Drawing.Size(55, 17);
            this.normal.TabIndex = 2;
            this.normal.TabStop = true;
            this.normal.Text = "Todos";
            this.normal.UseVisualStyleBackColor = true;
            this.normal.CheckedChanged += new System.EventHandler(this.normal_CheckedChanged);
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1019, 496);
            this.Controls.Add(this.datosFormulario);
            this.Controls.Add(this.guardarForm);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.txtValorDeclarado);
            this.Controls.Add(this.declarado);
            this.Controls.Add(this.fecha);
            this.Controls.Add(this.txtFecha);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.name);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.id);
            this.Controls.Add(this.txtNumForm);
            this.Controls.Add(this.numFormulario);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Declaracion de avisos y tableros";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datosFormulario)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtValorDeclarado;
        private System.Windows.Forms.Label declarado;
        private System.Windows.Forms.Label fecha;
        private System.Windows.Forms.DateTimePicker txtFecha;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Label id;
        private System.Windows.Forms.TextBox txtNumForm;
        private System.Windows.Forms.Label numFormulario;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.RadioButton listEmplazamiento;
        private System.Windows.Forms.RadioButton listNoEmplazamiento;
        private System.Windows.Forms.Button guardarForm;
        private System.Windows.Forms.DataGridView datosFormulario;
        private System.Windows.Forms.DataGridViewTextBoxColumn numForm;
        private System.Windows.Forms.DataGridViewTextBoxColumn NC;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn date;
        private System.Windows.Forms.DataGridViewTextBoxColumn estadoEmplazado;
        private System.Windows.Forms.DataGridViewTextBoxColumn valorDeclarado;
        private System.Windows.Forms.DataGridViewTextBoxColumn sancion;
        private System.Windows.Forms.DataGridViewTextBoxColumn extemporaneo;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalPagado;
        private System.Windows.Forms.RadioButton normal;
    }
}

