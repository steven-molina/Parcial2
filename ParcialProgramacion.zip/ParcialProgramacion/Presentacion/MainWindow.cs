﻿using Entidades;
using Logica;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class MainWindow : Form
    {
        private readonly LogicaFormulario logicaFormulario = new LogicaFormulario();
        private bool emplazado = false;
        readonly List<TextBox> textBoxes;

        public MainWindow()
        {
            InitializeComponent();
            textBoxes = new List<TextBox>
            {
                txtNumForm,
                txtValorDeclarado,
                txtId
            };

            foreach (var txt in textBoxes)
            {
                txt.KeyPress += new KeyPressEventHandler(OnlyNums);
            }
            datosFormulario.AutoGenerateColumns = false;
            CargarDatos("");
        }

        private void GuardarForm_Click(object sender, EventArgs e)
        {
            if (txtNumForm.Text == "" || txtId.Text == "" || 
                txtName.Text == "" || txtValorDeclarado.Text == "")
            {
                MessageBox.Show("Faltan algunos datos, verifique", "Campos vacios", MessageBoxButtons.OK);
            }else
            {
                Formulario formulario = new Formulario
                {
                    NumForm = int.Parse(txtNumForm.Text),
                    PersonaAsociada = new Persona(txtId.Text, txtName.Text, emplazado),
                    FechaDeclaracion = txtFecha.Value,
                    ValorDeclarado = double.Parse(txtValorDeclarado.Text),
                    DiasExtemporaneo = txtFecha.Value.Day > 10 ? txtFecha.Value.Day - 10 : 0
                };

                var resultado = logicaFormulario.AgregarFormulario(formulario);
                MessageBox.Show(resultado, "Resultado proceso", MessageBoxButtons.OK);

                if (resultado == "Datos guardados exitosamente")
                {
                    datosFormulario.DataSource = logicaFormulario.ListarFormularios();
                    txtNumForm.Text = String.Empty;
                    txtId.Text = String.Empty;
                    txtName.Text = String.Empty;
                    txtValorDeclarado.Text = String.Empty;
                    txtFecha.Value = DateTime.Today;

                    if (listEmplazamiento.Checked)
                    {
                        CargarDatos("Con emplazamiento");
                    }
                    else if (listNoEmplazamiento.Checked)
                    {
                        CargarDatos("Sin emplazamiento");
                    }else
                    {
                        CargarDatos("");
                    }
                }
            }
        }

        private void TxtFecha_ValueChanged(object sender, EventArgs e)
        {
            if (txtFecha.Value.Day > 10)
            {
                MessageBox.Show("Retraso en el pago, se aplicará la respectiva sanción",
                    "Sanción", MessageBoxButtons.OK);
                var result = MessageBox.Show("¿Tiene emplazamiento?", "Emplazamiento", MessageBoxButtons.YesNo);
                emplazado = result == DialogResult.Yes;
            }else
            {
                emplazado = false;
            }
        }

        private void OnlyNums(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }


        private void CargarDatos(string tipoFiltro)
        {
            datosFormulario.DataSource = null;
            datosFormulario.Rows.Clear();
            foreach (var formulario in logicaFormulario.ListarFormularios())
            {
                if (tipoFiltro.Equals(String.Empty))
                {
                    CargarGrilla(formulario);
                }
                else if (tipoFiltro.Equals("Sin emplazamiento"))
                {
                    if(!formulario.PersonaAsociada.Emplazado)
                    {
                        CargarGrilla(formulario);
                    }
                }else
                {
                    if (formulario.PersonaAsociada.Emplazado)
                    {
                        CargarGrilla(formulario);
                    }
                }
            }
        }

        private void CargarGrilla(Formulario formulario)
        {
            var fila = new DataGridViewRow();
            fila.CreateCells(datosFormulario);
            fila.Cells[0].Value = formulario.NumForm;
            fila.Cells[1].Value = formulario.PersonaAsociada.Id;
            fila.Cells[2].Value = formulario.PersonaAsociada.Name;
            fila.Cells[3].Value = formulario.FechaDeclaracion.ToShortDateString();
            fila.Cells[4].Value = formulario.PersonaAsociada.Emplazado ? "Si" : "No";
            fila.Cells[5].Value = formulario.ValorDeclarado;
            fila.Cells[6].Value = formulario.Sancion;
            fila.Cells[7].Value = formulario.DiasExtemporaneo;
            fila.Cells[8].Value = formulario.TotalPagado;
            datosFormulario.Rows.Add(fila);
        }

        private void ListEmplazamiento_CheckedChanged(object sender, EventArgs e)
        {
            if(listEmplazamiento.Checked) CargarDatos("Con emplazamiento");
        }

        private void ListNoEmplazamiento_CheckedChanged(object sender, EventArgs e)
        {
            if(listNoEmplazamiento.Checked) CargarDatos("Sin emplazamiento");
        }

        private void normal_CheckedChanged(object sender, EventArgs e)
        {
            if (normal.Checked) CargarDatos("");
        }
    }
}
